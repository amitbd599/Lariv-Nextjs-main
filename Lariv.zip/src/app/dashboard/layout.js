export const revalidate = 0; 
export default function Layout({ children }) {
  return <main>{children}</main>;
}
